
package General;


public class InversionSolicitud {
        int numsolc;
    int diasolicitud;
    int messolicitud;
    int añosolicitud;
    String nombrec;
    int cedulac;
    int dianacimiento;
    int mesnacimiento;
    int añonacimiento;
    int edadc;
    String sexoc;
    int inversion;
    int tim_iv;
    String ciudadc;
    String direccionc;
    int celularc;
    String emailc;
    String estado;
    public InversionSolicitud(){
        
    }
    public InversionSolicitud(String estado,int numsolc, int diasolicitud, int messolicitud, int añosolicitud, String nombrec, int cedulac, int dianacimiento, int mesnacimiento, int añonacimiento, int edadc, String sexoc, int inversion, int tim_iv, String ciudadc, String direccionc, int celularc, String emailc) {
        this.numsolc = numsolc;
        this.diasolicitud = diasolicitud;
        this.messolicitud = messolicitud;
        this.añosolicitud = añosolicitud;
        this.nombrec = nombrec;
        this.cedulac = cedulac;
        this.dianacimiento = dianacimiento;
        this.mesnacimiento = mesnacimiento;
        this.añonacimiento = añonacimiento;
        this.edadc = edadc;
        this.sexoc = sexoc;
        this.inversion = inversion;
        this.tim_iv = tim_iv;
        this.ciudadc = ciudadc;
        this.direccionc = direccionc;
        this.celularc = celularc;
        this.emailc = emailc;
        this.estado=estado;
    }

    public void setNumsolc(int numsolc) {
        this.numsolc = numsolc;
    }

    public void setDiasolicitud(int diasolicitud) {
        this.diasolicitud = diasolicitud;
    }

    public void setMessolicitud(int messolicitud) {
        this.messolicitud = messolicitud;
    }

    public void setAñosolicitud(int añosolicitud) {
        this.añosolicitud = añosolicitud;
    }

    public void setNombrec(String nombrec) {
        this.nombrec = nombrec;
    }

    public void setCedulac(int cedulac) {
        this.cedulac = cedulac;
    }

    public void setDianacimiento(int dianacimiento) {
        this.dianacimiento = dianacimiento;
    }

    public void setMesnacimiento(int mesnacimiento) {
        this.mesnacimiento = mesnacimiento;
    }

    public void setAñonacimiento(int añonacimiento) {
        this.añonacimiento = añonacimiento;
    }

    public void setEdadc(int edadc) {
        this.edadc = edadc;
    }

    public void setSexoc(String sexoc) {
        this.sexoc = sexoc;
    }

    public void setInversion(int inversion) {
        this.inversion = inversion;
    }

    public void setTim_iv(int tim_iv) {
        this.tim_iv = tim_iv;
    }

    public void setCiudadc(String ciudadc) {
        this.ciudadc = ciudadc;
    }

    public void setDireccionc(String direccionc) {
        this.direccionc = direccionc;
    }

    public void setCelularc(int celularc) {
        this.celularc = celularc;
    }

    public void setEmailc(String emailc) {
        this.emailc = emailc;
    }

    public int getNumsolc() {
        return numsolc;
    }

    public int getDiasolicitud() {
        return diasolicitud;
    }

    public int getMessolicitud() {
        return messolicitud;
    }

    public int getAñosolicitud() {
        return añosolicitud;
    }

    public String getNombrec() {
        return nombrec;
    }

    public int getCedulac() {
        return cedulac;
    }

    public int getDianacimiento() {
        return dianacimiento;
    }

    public int getMesnacimiento() {
        return mesnacimiento;
    }

    public int getAñonacimiento() {
        return añonacimiento;
    }

    public int getEdadc() {
        return edadc;
    }

    public String getSexoc() {
        return sexoc;
    }

    public int getInversion() {
        return inversion;
    }

    public int getTim_iv() {
        return tim_iv;
    }

    public String getCiudadc() {
        return ciudadc;
    }

    public String getDireccionc() {
        return direccionc;
    }

    public int getCelularc() {
        return celularc;
    }

    public String getEmailc() {
        return emailc;
    }
    public void setEstado(String estado) {
        this.estado=estado;
    }

}